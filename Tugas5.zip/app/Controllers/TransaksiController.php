<?php

namespace App\Controllers;

class TransaksiController extends BaseController
{
    public function index()
    {
        return view('v_keranjang');
    }
}
