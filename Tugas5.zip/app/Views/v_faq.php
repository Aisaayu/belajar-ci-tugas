<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman FAQ
<?= $this->endSection() ?>